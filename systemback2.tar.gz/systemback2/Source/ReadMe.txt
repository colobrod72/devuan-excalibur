Compile the Source-Code:
========================

open the systemback folder
open a terminal there and type:

debuild

In some cases additional packages have to be installed.
