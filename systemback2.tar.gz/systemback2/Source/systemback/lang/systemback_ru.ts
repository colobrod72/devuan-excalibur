<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru">
<context>
    <name>systemback</name>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="178"/>
        <source>Version:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="178"/>
        <source>Compilation date and time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="178"/>
        <location filename="../libsystemback/sblib.cpp" line="181"/>
        <source>Installed files:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="191"/>
        <source>Operating system:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="202"/>
        <location filename="../libsystemback/sblib.cpp" line="203"/>
        <source>Mounted filesystems:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="225"/>
        <source>System language:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="225"/>
        <source>Translation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="101"/>
        <source>The specified debug level is invalid!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="101"/>
        <source>The default level (1) will be used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="324"/>
        <source>An error occurred while opening the following file:</source>
        <translation>Произошла ошибка при открытии следующего файла:</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="451"/>
        <source>An error occurred while creating the following directory:</source>
        <translation>Произошла ошибка при создании следующего каталога:</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="453"/>
        <source>An error occurred while removing the following file:</source>
        <translation>Произошла ошибка при удалении следующего файла:</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="455"/>
        <source>An error occurred while creating the following hard link:</source>
        <translation>Произошла ошибка при создании следующей жесткой ссылки:</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="455"/>
        <source>Reference file:</source>
        <translation>Ссылка файла:</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="462"/>
        <source>An error occurred while creating the following file:</source>
        <translation>Произошла ошибка при создании следующего файла:</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="473"/>
        <source>An error occurred while renaming the following item:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="473"/>
        <source>New path:</source>
        <translation>Новый путь:</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="796"/>
        <source>An error occurred while executing the following command:</source>
        <translation>Произошла ошибка при выполнении следующей команды:</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="796"/>
        <source>Exit code:</source>
        <translation>Код выхода:</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="972"/>
        <source>Failed to detect the device for installing the GRUB!</source>
        <translation>Не удалось обнаружить устройство для установки GRUB!</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="1095"/>
        <source>An error occurred while upgrading the system!</source>
        <translation>Произошла ошибка при обновлении системы!</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="1096"/>
        <source>Restart upgrade ...</source>
        <translation>Перезапуск обновления ...</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="1120"/>
        <source>This file could not be copied because it does not exist:</source>
        <translation>Этот файл не может быть скопирован, потому что не существует:</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="1133"/>
        <source>The following partition has no UUID:</source>
        <translation>Этот раздел не имеет UUID:</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="1151"/>
        <source>An error occurred while creating a new partition on the following device:</source>
        <translation>Произошла ошибка при создании нового раздела на следующем устройстве:</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="1164"/>
        <source>An error occurred while mounting the following partition/image:</source>
        <translation>Произошла ошибка при монтировании следующего раздела/образа:</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="1196"/>
        <source>An error occurred while setting one or more flags on the following partition:</source>
        <translation>Произошла ошибка при установке одного или более флагов на следующий раздел:</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="1196"/>
        <source>Flag(s):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="1216"/>
        <source>An error occurred while creating the partition table on the following device:</source>
        <translation>Произошла ошибка при создании таблицы разделов на следующем устройстве:</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="1238"/>
        <source>An error occurred while unmounting the following partition/image/mount point:</source>
        <translation>Произошла ошибка при размонтировании следующего раздела/образа/точки монтирования:</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="1288"/>
        <source>An error occurred while cloning the properties of the following item:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="1288"/>
        <source>Target item:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="1320"/>
        <source>An error occurred while cloning the following symbolic link:</source>
        <translation>Произошла ошибка при клонировании следующей символической ссылки:</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="1320"/>
        <source>Target symlink:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="1333"/>
        <source>An error occurred while cloning the following file:</source>
        <translation>Произошла ошибка при клонировании следующего файла:</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="1333"/>
        <source>Target file:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="1384"/>
        <source>An error occurred while cloning the following directory:</source>
        <translation>Произошла ошибка при клонировании следующего каталога:</translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="1384"/>
        <source>Target directory:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../libsystemback/sblib.cpp" line="1769"/>
        <source>An error occurred while deleting the following directory:</source>
        <translation>Произошла ошибка при удалении следующего каталога:</translation>
    </message>
    <message>
        <location filename="../sbscheduler/sbscheduler.cpp" line="40"/>
        <location filename="../sbsustart/sbsustart.cpp" line="123"/>
        <source>Cannot start the Systemback scheduler daemon!</source>
        <translation>Не удается запустить демон - планировщик Systemback!</translation>
    </message>
    <message>
        <location filename="../sbscheduler/sbscheduler.cpp" line="43"/>
        <location filename="../sbsustart/sbsustart.cpp" line="120"/>
        <source>Missing, wrong or too much argument(s).</source>
        <translation>Параметры отсутствуют или ошибочны (или их слишком много).</translation>
    </message>
    <message>
        <location filename="../sbscheduler/sbscheduler.cpp" line="45"/>
        <source>The process is disabled for this user.</source>
        <translation>Процесс запрещен для этого пользователя.</translation>
    </message>
    <message>
        <location filename="../sbscheduler/sbscheduler.cpp" line="47"/>
        <source>Root privileges are required.</source>
        <translation>Требуются права root.</translation>
    </message>
    <message>
        <location filename="../sbscheduler/sbscheduler.cpp" line="49"/>
        <source>This system is a Live.</source>
        <translation>Эта система является т.н. Live-CD.</translation>
    </message>
    <message>
        <location filename="../sbscheduler/sbscheduler.cpp" line="51"/>
        <source>Already running.</source>
        <translation>Уже выполняется.</translation>
    </message>
    <message>
        <location filename="../sbscheduler/sbscheduler.cpp" line="53"/>
        <source>Unable to daemonize.</source>
        <translation>Невозможно &quot;демонизировать&quot;.</translation>
    </message>
    <message>
        <location filename="../sbsustart/sbsustart.cpp" line="123"/>
        <source>Cannot start the Systemback graphical user interface!</source>
        <translation>Не удается запустить Systemback GUI!</translation>
    </message>
    <message>
        <location filename="../sbsustart/sbsustart.cpp" line="123"/>
        <source>Unable to get root permissions.</source>
        <translation>Не удалось получить права root.</translation>
    </message>
    <message>
        <location filename="../sbsustart/sbsustart.cpp" line="123"/>
        <source>Unable to connect to the X server.</source>
        <translation>Не удалось подключиться к X-серверу.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="162"/>
        <source>Full name of the new user:</source>
        <translation>Полное имя нового пользователя:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="175"/>
        <source>New username to login:</source>
        <translation>Новое имя для входа пользователя:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="188"/>
        <source>New user account password:</source>
        <translation>Новый пароль пользователя:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="201"/>
        <source>New root password (optional, not recommended for Ubuntu):</source>
        <translation>Новый пароль root (не обязательно, для Ubuntu НЕ рекомендовано!):</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="214"/>
        <source>New hostname:</source>
        <translation>Новое имя компютера (hostname):</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="230"/>
        <location filename="../systemback/systemback.ui" line="838"/>
        <location filename="../systemback/systemback.ui" line="1474"/>
        <location filename="../systemback/systemback.ui" line="1807"/>
        <location filename="../systemback/systemback.ui" line="2101"/>
        <location filename="../systemback/systemback.ui" line="2802"/>
        <location filename="../systemback/systemback.ui" line="2930"/>
        <location filename="../systemback/systemback.ui" line="3994"/>
        <location filename="../systemback/systemback.ui" line="5151"/>
        <location filename="../systemback/systemback.ui" line="5382"/>
        <location filename="../systemback/systemback.ui" line="6189"/>
        <location filename="../systemback/systemback.ui" line="6691"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="246"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="259"/>
        <location filename="../systemback/systemback.ui" line="1547"/>
        <location filename="../systemback/systemback.ui" line="4023"/>
        <location filename="../systemback/systemback.ui" line="5180"/>
        <location filename="../systemback/systemback.ui" line="5414"/>
        <source>Next</source>
        <translation>Далее</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="625"/>
        <location filename="../systemback/systemback.cpp" line="5138"/>
        <source>Working directory</source>
        <translation>Рабочий каталог</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="647"/>
        <source>Created Live images</source>
        <translation>Создание Live-образа</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="669"/>
        <source>Name of the Live system</source>
        <translation>Имя Live-системы</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="691"/>
        <location filename="../systemback/systemback.ui" line="1354"/>
        <location filename="../systemback/systemback.ui" line="1996"/>
        <location filename="../systemback/systemback.ui" line="5050"/>
        <location filename="../systemback/systemback.ui" line="5287"/>
        <source>Options</source>
        <translation>Опции</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="713"/>
        <source>Write target</source>
        <translation>Диск для записи</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="735"/>
        <source>Live operations</source>
        <translation>Действия с системой Live</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="822"/>
        <source>Include the user data files</source>
        <translation>Включить пользовательские файлы</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="883"/>
        <source>Redetect devices</source>
        <translation>Переопределить устройства</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="915"/>
        <location filename="../systemback/systemback.ui" line="3459"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="246"/>
        <source>Delete</source>
        <translation>Удалить</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="937"/>
        <source>Write to target</source>
        <translation>Записать на диск</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="959"/>
        <source>Convert to ISO</source>
        <translation>Преобразовать в ISO</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="981"/>
        <location filename="../systemback/systemback.ui" line="3393"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="179"/>
        <source>Create new</source>
        <translation>Создать новую</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="1209"/>
        <source>Mount the faulty system partition(s) to the &apos;/mnt&apos; directory according to the original structure.&lt;br&gt;(&apos;/&apos; -&gt; &apos;/mnt&apos;, &apos;/home&apos; -&gt; &apos;/mnt/home&apos;, etc.)</source>
        <translation>Смонтируйте неисправный системный раздел(ы) в каталог &apos;/mnt&apos; в соответствии с оригинальной&lt;br&gt;структурой. (&apos;/&apos; -&gt; &apos;/mnt&apos;, &apos;/home&apos; -&gt; &apos;/mnt/home&apos;, и т.д.)</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="1278"/>
        <location filename="../systemback/systemback.cpp" line="6212"/>
        <source>Mount</source>
        <translation>Монтировать</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="1303"/>
        <source>Reset mounts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="1332"/>
        <source>Repair type</source>
        <translation>Тип восстановления</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="1401"/>
        <source>GRUB 2 repair</source>
        <translation>Восстановление загрузчика GRUB 2</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="1420"/>
        <source>System files repair</source>
        <translation>Восстановление системных файлов</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="1436"/>
        <location filename="../systemback/systemback.ui" line="5110"/>
        <source>Reinstall GRUB 2 bootloader:</source>
        <translation>Переустановка загрузчика GRUB 2:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="1455"/>
        <location filename="../systemback/systemback.ui" line="5072"/>
        <source>Auto detection</source>
        <translation>Автоматическое определение</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="1503"/>
        <source>Full repair</source>
        <translation>Полное восстановление</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="1525"/>
        <source>Do not repair the fstab file</source>
        <translation>Не восстановлен файл fstab</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="1645"/>
        <source>Exclude hidden user files and directories from restore points</source>
        <translation>Исключить скрытые файлы и каталоги пользоватлей из точки восстановления</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="1667"/>
        <source>Exclude user data files and directories from Live system</source>
        <translation>Исключить файлы и каталоги пользователя из Live-системы</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="1686"/>
        <source>Excludable items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="1708"/>
        <source>Excluded items</source>
        <translation>Исключенные элементы</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="1733"/>
        <location filename="../systemback/systemback.ui" line="6617"/>
        <source>Remove item from the exclusion list</source>
        <translation>Удалить элемент из списка исключений</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="1765"/>
        <location filename="../systemback/systemback.ui" line="6649"/>
        <source>Add item to the exclusion list</source>
        <translation>Добавить элемент в список исключений</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="1927"/>
        <source>Scheduler state:</source>
        <translation>Состояние планировщика:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="1946"/>
        <location filename="../systemback/systemback.cpp" line="649"/>
        <location filename="../systemback/systemback.cpp" line="849"/>
        <location filename="../systemback/systemback.cpp" line="1853"/>
        <location filename="../systemback/systemback.cpp" line="1944"/>
        <location filename="../systemback/systemback.cpp" line="2551"/>
        <location filename="../systemback/systemback.cpp" line="4158"/>
        <location filename="../systemback/systemback.cpp" line="5559"/>
        <location filename="../systemback/systemback.cpp" line="5573"/>
        <location filename="../systemback/systemback.cpp" line="5574"/>
        <location filename="../systemback/systemback.cpp" line="6790"/>
        <source>Disabled</source>
        <translation>Выключен</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="1974"/>
        <source>Timer settings</source>
        <translation>Настройки таймера</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="2012"/>
        <source>Waiting time before creating a new restore point:</source>
        <translation>Время ожидания перед созданием новой точки восстановления:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="2025"/>
        <source>Visible countdown time:</source>
        <translation>Показать обратный отсчет времени:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="2038"/>
        <source>Pop-up window position on screen:</source>
        <translation>Позиция всплывающего окна на экране:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="2060"/>
        <source>Use silent mode</source>
        <translation>Использовать &quot;скрытый&quot; режим</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="2167"/>
        <location filename="../systemback/systemback.ui" line="2208"/>
        <location filename="../systemback/systemback.ui" line="2249"/>
        <location filename="../systemback/systemback.ui" line="2512"/>
        <source>More</source>
        <translation>Больше</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="2290"/>
        <location filename="../systemback/systemback.ui" line="2331"/>
        <location filename="../systemback/systemback.ui" line="2372"/>
        <location filename="../systemback/systemback.ui" line="2553"/>
        <source>Less</source>
        <translation>Меньше</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="2615"/>
        <source>Simple system backup and restore application with extra features</source>
        <translation>Простое резервное копирование системы и восстановление данных</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="2628"/>
        <source>Project homepage:</source>
        <translation>Домашняя страница проекта:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="2683"/>
        <source>Contact:</source>
        <translation>Контактная информация:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="2717"/>
        <source>Donate:</source>
        <translation>Пожертвовать:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="2754"/>
        <source>Systemback version:</source>
        <translation>Версия Systemback:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="2831"/>
        <location filename="../systemback/systemback.cpp" line="4532"/>
        <source>License</source>
        <translation>Лицензия</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="2982"/>
        <source>Re-read directories</source>
        <translation>Перечитать каталоги</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3014"/>
        <source>Writable Linux filesystem!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3052"/>
        <location filename="../systemback/systemback.ui" line="7409"/>
        <location filename="../systemback/systemback.ui" line="7675"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="381"/>
        <source>Cancel</source>
        <translation>Отменить</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3145"/>
        <location filename="../systemback/systemback.ui" line="3167"/>
        <location filename="../systemback/systemback.ui" line="3189"/>
        <location filename="../systemback/systemback.ui" line="3211"/>
        <location filename="../systemback/systemback.ui" line="3236"/>
        <location filename="../systemback/systemback.ui" line="3261"/>
        <location filename="../systemback/systemback.ui" line="3283"/>
        <location filename="../systemback/systemback.ui" line="3305"/>
        <source>Maximum number of temporary restore points</source>
        <translation>Максимальное количество временных точек восстановления</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3324"/>
        <source>Restore points</source>
        <translation>Точки восстановления</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3346"/>
        <source>Highlighted restore points</source>
        <translation>Выделенные точки</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3368"/>
        <source>Point operations</source>
        <translation>Действия</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3415"/>
        <source>Highlight</source>
        <translation>Выделить</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3437"/>
        <source>Rename</source>
        <translation>Переименовать</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3481"/>
        <location filename="../systemback/systemback.ui" line="3503"/>
        <location filename="../systemback/systemback.ui" line="3525"/>
        <location filename="../systemback/systemback.ui" line="3547"/>
        <location filename="../systemback/systemback.ui" line="3569"/>
        <location filename="../systemback/systemback.ui" line="4583"/>
        <location filename="../systemback/systemback.ui" line="4605"/>
        <location filename="../systemback/systemback.ui" line="4627"/>
        <location filename="../systemback/systemback.ui" line="4649"/>
        <location filename="../systemback/systemback.ui" line="4671"/>
        <location filename="../systemback/systemback.ui" line="4693"/>
        <location filename="../systemback/systemback.ui" line="4715"/>
        <location filename="../systemback/systemback.ui" line="4737"/>
        <location filename="../systemback/systemback.ui" line="4759"/>
        <location filename="../systemback/systemback.ui" line="4781"/>
        <source>Select restore point</source>
        <translation>Выберите точку восстановления</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3588"/>
        <location filename="../systemback/systemback.cpp" line="5124"/>
        <location filename="../systemback/systemback.cpp" line="5168"/>
        <location filename="../systemback/systemback.cpp" line="5274"/>
        <location filename="../systemback/systemback.cpp" line="5315"/>
        <location filename="../systemback/systemback.cpp" line="5332"/>
        <source>Storage directory</source>
        <translation>Каталог хранения</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3610"/>
        <source>Function menu</source>
        <translation>Меню</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3653"/>
        <location filename="../systemback/systemback.cpp" line="4078"/>
        <source>Schedule</source>
        <translation>Расписание</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3685"/>
        <location filename="../systemback/systemback.cpp" line="4086"/>
        <location filename="../systemback/systemback.cpp" line="4524"/>
        <source>About</source>
        <translation>О программе</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3717"/>
        <location filename="../systemback/systemback.cpp" line="4094"/>
        <source>Settings</source>
        <translation>Настройки</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3749"/>
        <source>System upgrade</source>
        <translation>Обновление системы</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3771"/>
        <location filename="../systemback/systemback.cpp" line="3977"/>
        <source>System install</source>
        <translation>Установка системы</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3803"/>
        <location filename="../systemback/systemback.cpp" line="3992"/>
        <location filename="../systemback/systemback.cpp" line="5321"/>
        <location filename="../systemback/systemback.cpp" line="5364"/>
        <source>Live system create</source>
        <translation>Создание системы Live</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3835"/>
        <location filename="../systemback/systemback.cpp" line="4023"/>
        <source>System repair</source>
        <translation>Ремонт системы</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3867"/>
        <location filename="../systemback/systemback.cpp" line="3901"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="246"/>
        <source>System restore</source>
        <translation>Восстановление системы</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3899"/>
        <location filename="../systemback/systemback.cpp" line="3942"/>
        <location filename="../systemback/systemback.cpp" line="4450"/>
        <location filename="../systemback/systemback.cpp" line="6120"/>
        <source>System copy</source>
        <translation>Копирование системы</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3931"/>
        <location filename="../systemback/systemback.cpp" line="4056"/>
        <source>Exclude</source>
        <translation>Исключить</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="3963"/>
        <location filename="../systemback/systemback.cpp" line="4067"/>
        <source>Include</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="4125"/>
        <source>Change path</source>
        <translation>Изменить путь</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="4163"/>
        <location filename="../systemback/systemback.ui" line="4191"/>
        <location filename="../systemback/systemback.ui" line="4219"/>
        <location filename="../systemback/systemback.ui" line="4247"/>
        <location filename="../systemback/systemback.ui" line="4275"/>
        <location filename="../systemback/systemback.ui" line="4443"/>
        <location filename="../systemback/systemback.ui" line="4471"/>
        <location filename="../systemback/systemback.ui" line="4499"/>
        <location filename="../systemback/systemback.ui" line="4527"/>
        <location filename="../systemback/systemback.ui" line="4555"/>
        <location filename="../systemback/systemback.cpp" line="1802"/>
        <location filename="../systemback/systemback.cpp" line="1803"/>
        <location filename="../systemback/systemback.cpp" line="1807"/>
        <location filename="../systemback/systemback.cpp" line="3724"/>
        <location filename="../systemback/systemback.cpp" line="3726"/>
        <source>empty</source>
        <translation>пустой</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="4303"/>
        <location filename="../systemback/systemback.ui" line="4331"/>
        <location filename="../systemback/systemback.ui" line="4359"/>
        <location filename="../systemback/systemback.ui" line="4387"/>
        <location filename="../systemback/systemback.ui" line="4415"/>
        <location filename="../systemback/systemback.cpp" line="1800"/>
        <location filename="../systemback/systemback.cpp" line="3724"/>
        <location filename="../systemback/systemback.cpp" line="3727"/>
        <source>not used</source>
        <translation>не используется</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="4908"/>
        <source>Restore type</source>
        <translation>Тип восстановления</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="4930"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="377"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="412"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="451"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="479"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="507"/>
        <source>Full restore</source>
        <translation>Полное восстановление</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="4952"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="377"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="414"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="451"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="479"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="507"/>
        <source>System files restore</source>
        <translation>Восстановление системных файлов</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="4971"/>
        <source>User(s) configuration files restore</source>
        <translation>Восстановление конфигурационных файлов пользователя(ей)</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="4993"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="381"/>
        <source>Keep newly installed configuration files</source>
        <translation>Сохранить вновь установленные файлы конфигурации</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="5006"/>
        <source>Include user(s):</source>
        <translation>Включить в состав пользователя(ей):</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="5097"/>
        <source>Do not restore the fstab file</source>
        <translation>Не восстанавливать файл fstab</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="5265"/>
        <source>Partition settings</source>
        <translation>Настройки разделов</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="5309"/>
        <location filename="../systemback/systemback.cpp" line="370"/>
        <location filename="../systemback/systemback.cpp" line="1760"/>
        <location filename="../systemback/systemback.cpp" line="5612"/>
        <location filename="../systemback/systemback.cpp" line="5613"/>
        <source>Transfer user configuration files</source>
        <translation>Перенести конфигурационные файлы пользователя</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="5331"/>
        <source>Copy user data files</source>
        <translation>Копировать файлы данных пользователя</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="5366"/>
        <source>Install GRUB 2 bootloader:</source>
        <translation>Установить загрузчик GRUB 2:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="5590"/>
        <location filename="../systemback/systemback.cpp" line="640"/>
        <location filename="../systemback/systemback.cpp" line="646"/>
        <source>Format</source>
        <translation>Форматировать</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="5612"/>
        <location filename="../systemback/systemback.ui" line="5787"/>
        <location filename="../systemback/systemback.ui" line="5920"/>
        <source>Reset partitions settings</source>
        <translation>Сбросить настройки разделов</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="5644"/>
        <location filename="../systemback/systemback.ui" line="5853"/>
        <location filename="../systemback/systemback.cpp" line="3509"/>
        <location filename="../systemback/systemback.cpp" line="4129"/>
        <location filename="../systemback/systemback.cpp" line="4321"/>
        <location filename="../systemback/systemback.cpp" line="5787"/>
        <location filename="../systemback/systemback.cpp" line="5835"/>
        <source>Unmount</source>
        <translation>Отсоединить</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="5691"/>
        <source>Change partition settings</source>
        <translation>Изменить настройки разделов</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="5717"/>
        <source>Filesystem:</source>
        <translation>Файловая система:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="5755"/>
        <source>Mount point:</source>
        <translation>Точка монтир:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="5825"/>
        <location filename="../systemback/systemback.cpp" line="371"/>
        <location filename="../systemback/systemback.cpp" line="4129"/>
        <location filename="../systemback/systemback.cpp" line="4352"/>
        <location filename="../systemback/systemback.cpp" line="5787"/>
        <location filename="../systemback/systemback.cpp" line="5835"/>
        <source>! Delete !</source>
        <translation>! Удалить !</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="5888"/>
        <source>Add new partition</source>
        <translation>Добавить новый раздел</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="5946"/>
        <source>Create new:</source>
        <translation>Создать новый:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="5991"/>
        <source>Need to set the mount point as &apos;/boot/efi&apos;!</source>
        <translation>Необходимо установить точку монтирования как &apos;/boot/efi&apos;!</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="6027"/>
        <source>Window DPI scaling</source>
        <translation>Масшатирование DPI окна</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="6076"/>
        <source>Multiplier factor for scaling the window contents</source>
        <translation>Коэффициент масштабирования содержания окна</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="6218"/>
        <source>User interface</source>
        <translation>Интерфейс пользователя</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="6290"/>
        <source>Window always on top</source>
        <translation>Поверх всех окон</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="6309"/>
        <source>System</source>
        <translation>Система</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="6331"/>
        <source>Disable scheduler daemon starting for the following users:</source>
        <translation>Отключить автозапуск планировщика для следующих пользователей:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="6350"/>
        <source>Use XZ compressor for squashfs filesystems</source>
        <translation>Использовать сжатие XZ для файловых систем Squashfs</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="6369"/>
        <source>Override auto-detected language:</source>
        <translation>Переопределить автоматическое определение языка:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="6388"/>
        <source>Override the used style:</source>
        <translation>Переопределить используемый стиль:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="6407"/>
        <source>Disable incremental restore points (do not use hard links between backups)</source>
        <translation>Отключить инкрементальные точки восстановления</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="6519"/>
        <source>Create Live ISO images automatically (faster than the conversion)</source>
        <translation>Создать образ iso Live автоматически (быстрее, чем преобразование)</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="6538"/>
        <source>Do not empty memory cache at the end of some processes</source>
        <translation>Не очищать кэш памяти в конце некоторых процессов</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="6570"/>
        <source>Includable items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="6592"/>
        <source>Included items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="6804"/>
        <source>Include user data files and directories into the restore points
These will be defined as restorable configuration files!</source>
        <translation>Включить файлы данных и директории пользователя в точки восстановления
Они будут определены как восстанавливаемые файлы конфигурации!</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="6998"/>
        <source>! Interrupt !</source>
        <translation>! Прервать !</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="7149"/>
        <source>Creates a scheduled restore point within few seconds.</source>
        <translation>Создает точку восстановления по расписанию в течение нескольких секунд.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="7177"/>
        <location filename="../systemback/systemback.cpp" line="2712"/>
        <location filename="../systemback/systemback.cpp" line="5002"/>
        <source>Start</source>
        <translation>Старт</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="7202"/>
        <source>Later</source>
        <translation>Позже</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="7523"/>
        <source>Systemback user authentication</source>
        <translation>Аутентификация пользователя Systemback</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="7542"/>
        <source>Administrator:</source>
        <translation>Администратор:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.ui" line="7577"/>
        <source>Password:</source>
        <translation>Пароль:</translation>
    </message>
    <message>
        <location filename="../systemback/main.cpp" line="30"/>
        <source>Unsafe X Window authorization!</source>
        <translation>Небезопасная авторизация X Window!!</translation>
    </message>
    <message>
        <location filename="../systemback/main.cpp" line="30"/>
        <source>Please do not use &apos;sudo&apos; command.</source>
        <translation>Пожалуйста, не используйте команду &apos;sudo&apos;.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="369"/>
        <location filename="../systemback/systemback.cpp" line="370"/>
        <location filename="../systemback/systemback.cpp" line="802"/>
        <location filename="../systemback/systemback.cpp" line="1760"/>
        <location filename="../systemback/systemback.cpp" line="5612"/>
        <location filename="../systemback/systemback.cpp" line="5619"/>
        <source>Transfer user configuration and data files</source>
        <translation>Перенести файлы данных и конфигурации пользователя</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="440"/>
        <location filename="../systemback/systemback.cpp" line="2922"/>
        <location filename="../systemback/systemback.cpp" line="3631"/>
        <source>scheduler</source>
        <translation>планировщик</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="640"/>
        <location filename="../systemback/systemback.cpp" line="646"/>
        <source>Partition</source>
        <translation>Раздел</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="640"/>
        <location filename="../systemback/systemback.cpp" line="646"/>
        <source>Size</source>
        <translation>Размер</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="640"/>
        <source>Label</source>
        <translation>Метка</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="640"/>
        <source>Current mount point</source>
        <translation>Текущая точка монтирования</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="640"/>
        <source>New mount point</source>
        <translation>Новая точка монтирования</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="640"/>
        <source>Filesystem</source>
        <translation>Файловая система</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="646"/>
        <source>Device</source>
        <translation>Устройство</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="652"/>
        <location filename="../systemback/systemback.cpp" line="6917"/>
        <source>Top left</source>
        <translation>Сверху слева</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="652"/>
        <location filename="../systemback/systemback.cpp" line="653"/>
        <location filename="../systemback/systemback.cpp" line="6918"/>
        <source>Top right</source>
        <translation>Сверху справа</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="652"/>
        <location filename="../systemback/systemback.cpp" line="653"/>
        <location filename="../systemback/systemback.cpp" line="6919"/>
        <source>Center</source>
        <translation>В центре</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="652"/>
        <location filename="../systemback/systemback.cpp" line="653"/>
        <location filename="../systemback/systemback.cpp" line="6920"/>
        <source>Bottom left</source>
        <translation>Снизу слева</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="652"/>
        <location filename="../systemback/systemback.cpp" line="653"/>
        <source>Bottom right</source>
        <translation>Снизу справа</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="654"/>
        <location filename="../systemback/systemback.cpp" line="6824"/>
        <location filename="../systemback/systemback.cpp" line="6833"/>
        <source>day(s)</source>
        <translation>день(дней)</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="655"/>
        <location filename="../systemback/systemback.cpp" line="6853"/>
        <location filename="../systemback/systemback.cpp" line="6862"/>
        <source>hour(s)</source>
        <translation>ч</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="656"/>
        <location filename="../systemback/systemback.cpp" line="6841"/>
        <location filename="../systemback/systemback.cpp" line="6870"/>
        <location filename="../systemback/systemback.cpp" line="6882"/>
        <location filename="../systemback/systemback.cpp" line="6890"/>
        <source>minute(s)</source>
        <translation>мин</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="657"/>
        <location filename="../systemback/systemback.cpp" line="6898"/>
        <location filename="../systemback/systemback.cpp" line="6906"/>
        <source>seconds</source>
        <translation>сек</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="762"/>
        <location filename="../systemback/systemback.cpp" line="3897"/>
        <location filename="../systemback/systemback.cpp" line="7690"/>
        <location filename="../systemback/systemback.cpp" line="7706"/>
        <source>Everyone</source>
        <translation>Все</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="925"/>
        <location filename="../systemback/systemback.cpp" line="1052"/>
        <location filename="../systemback/systemback.cpp" line="4604"/>
        <source>Currently running system</source>
        <translation>Текущая работающая система</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1263"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="574"/>
        <source>Emptying cache</source>
        <translation>Очистка кеш-памяти</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1263"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="574"/>
        <source>Flushing filesystem buffers</source>
        <translation>Сброс буфера файловой системы</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1265"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="584"/>
        <source>Restoring the full system</source>
        <translation>Восстановление всей системы</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1267"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="586"/>
        <source>Restoring the system files</source>
        <translation>Восстановление системних файлов</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1269"/>
        <source>Restoring the user(s) configuration files</source>
        <translation>Восстановление конфигурационных файлов пользователя (ей)</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1271"/>
        <source>Repairing the system files</source>
        <translation>Ремонт системных файлов</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1273"/>
        <source>Repairing the full system</source>
        <translation>Ремонт всей системы</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1275"/>
        <source>Repairing the GRUB 2</source>
        <translation>Ремонт GRUB 2</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1277"/>
        <source>Copying the system</source>
        <translation>Копирование системы</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1279"/>
        <source>Installing the system</source>
        <translation>Установка системы</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1281"/>
        <source>Writing Live image to the target device</source>
        <translation>Запись образаLive на носитель</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1283"/>
        <source>Upgrading the system</source>
        <translation>Обновление системы</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1285"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="578"/>
        <source>Deleting incomplete restore point</source>
        <translation>Удаление незавершенной точки восстановления</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1287"/>
        <source>Interrupting the current process</source>
        <translation>Прерывание текущего процесса</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1289"/>
        <source>Deleting old restore point</source>
        <translation>Удаление старой точки восстановления</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1291"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="582"/>
        <source>Creating restore point</source>
        <translation>Создание точки восстановления</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1293"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="576"/>
        <source>Deleting restore point</source>
        <translation>Удаление точки восстановления</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1295"/>
        <source>Converting Live system image</source>
        <translation>Преобразование системы Live</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1295"/>
        <location filename="../systemback/systemback.cpp" line="1297"/>
        <source>process</source>
        <translation>процесс</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1297"/>
        <source>Creating Live system</source>
        <translation>Создание системы Live</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1370"/>
        <location filename="../systemback/systemback.cpp" line="2769"/>
        <location filename="../systemback/systemback.cpp" line="2774"/>
        <location filename="../systemback/systemback.cpp" line="2794"/>
        <location filename="../systemback/systemback.cpp" line="3677"/>
        <location filename="../systemback/systemback.cpp" line="5016"/>
        <source>Reboot</source>
        <translation>Перезагрузка</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="1370"/>
        <location filename="../systemback/systemback.cpp" line="2753"/>
        <location filename="../systemback/systemback.cpp" line="2758"/>
        <location filename="../systemback/systemback.cpp" line="5028"/>
        <source>X restart</source>
        <translation>Перезапуск X</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2124"/>
        <location filename="../systemback/systemback.cpp" line="4007"/>
        <location filename="../systemback/systemback.cpp" line="4611"/>
        <source>Live image</source>
        <translation>Образ Live</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2717"/>
        <source>Restore the system files to the following restore point:</source>
        <translation>Восстановление системных файлов из указанной точки восстановления:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2719"/>
        <source>Repair the system files with the following restore point:</source>
        <translation>Ремонт системных файлов из указанной точки восстановления:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2721"/>
        <source>Repair the complete system with the following restore point:</source>
        <translation>Ремонт всей системы из указанной точки восстановления:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2723"/>
        <source>Restore the complete user(s) configuration files to the following restore point:</source>
        <translation>Полное восстановление конфигурационных файлов пользователя(ей) из указанной точки восстановления:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2725"/>
        <source>Restore the user(s) configuration files to the following restore point:</source>
        <translation>Восстановление конфигурационных файлов пользователя(ей) из указанной точки восстановления:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2727"/>
        <source>Copy the system, using the following restore point:</source>
        <translation>Копирование системы из указанной точки восстановления:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2729"/>
        <source>Install the system, using the following restore point:</source>
        <translation>Установка системы из указанной точки восстановления:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2731"/>
        <source>Restore the complete system to the following restore point:</source>
        <translation>Восстановление системы целиком из указанной точки восстановления:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2733"/>
        <source>Format the %1, and write the following Live system image:</source>
        <translation>Форматирование %1, и запись указаного образа системы Live:</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2735"/>
        <source>Repair the GRUB 2 bootloader.</source>
        <translation>Ремонт загрузчика GRUB 2.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2756"/>
        <source>The user(s) configuration files full restoration are completed.</source>
        <translation>Полное восстановление конфигурационных файлов пользователя(ей) завершено.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2756"/>
        <location filename="../systemback/systemback.cpp" line="2761"/>
        <source>The X server will restart automatically within 30 seconds.</source>
        <translation>Х-сервер автоматически перезапустится в течении 30 секунд.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2761"/>
        <source>The user(s) configuration files restoration are completed.</source>
        <translation>Восстановление конфигурационных файлов пользователя завершено.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2764"/>
        <source>The full system repair is completed.</source>
        <translation>Полный ремонт системы завершён.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2767"/>
        <source>The system repair is completed.</source>
        <translation>Ремонт системы завершён.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2772"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="544"/>
        <source>The system files restoration are completed.</source>
        <translation>Восстановление системных файлов завершено.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2772"/>
        <location filename="../systemback/systemback.cpp" line="2777"/>
        <location filename="../systemback/systemback.cpp" line="2797"/>
        <source>The computer will restart automatically within 30 seconds.</source>
        <translation>Компютер будет автоматически перезагружен в течении 30 секунд.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2777"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="542"/>
        <source>The full system restoration is completed.</source>
        <translation>Полное восстановление системы завершено.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2780"/>
        <source>The system copy is completed.</source>
        <translation>Копирование системы завершено.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2783"/>
        <source>The Live system creation is completed.</source>
        <translation>Создание системы Live завершено.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2783"/>
        <source>The created .sblive file can be written to pendrive.</source>
        <translation>Созданный файл .sblive можно записать на флешку.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2786"/>
        <source>The GRUB 2 repair is completed.</source>
        <translation>Ремонт GRUB 2 завершён.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2789"/>
        <source>The system install is completed.</source>
        <translation>Установка системы завершена.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2792"/>
        <source>The Live system image write is completed.</source>
        <translation>Запись образа системы Live завершено.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2824"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="119"/>
        <source>An another Systemback process is currently running, please wait until it finishes.</source>
        <translation>Другой процесс Systemback в настоящее время работает, пожалуйста, подождите, пока он не завершится.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2826"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="121"/>
        <source>Unable to get exclusive lock!</source>
        <translation>Не удалось получить эксклюзивную блокировку!</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2826"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="121"/>
        <source>First, close all package manager.</source>
        <translation>Во-первых, закройте все менеджеры пакетов.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2828"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="123"/>
        <source>The re-synchronization of package index files currently in progress, please wait until it finishes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2830"/>
        <source>The specified name contain(s) unsupported character(s)!</source>
        <translation>Указанное имя содержит недопустимый(ые) символ(ы)!</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2830"/>
        <source>Please enter a new name.</source>
        <translation>Пожалуйста, введите новое имя.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2832"/>
        <source>The system files repair are completed, but an error occurred while reinstalling the GRUB!</source>
        <translation>Ремонт системных файлов завершён, но произошла ошибка при переустановке GRUB!</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2832"/>
        <location filename="../systemback/systemback.cpp" line="2844"/>
        <location filename="../systemback/systemback.cpp" line="2860"/>
        <source>The system may not bootable! (In general, the different architecture is causing the problem.)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2834"/>
        <location filename="../systemback/systemback.cpp" line="2862"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="135"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="137"/>
        <source>The restore point creation is aborted!</source>
        <translation>Создание точки восстановления было отменено!</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2834"/>
        <location filename="../systemback/systemback.cpp" line="2850"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="135"/>
        <source>Not enough free disk space to complete the process.</source>
        <translation>Не хватает свободного места на диске, чтобы завершить процесс.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2836"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="117"/>
        <source>Root privileges are required for running the Systemback!</source>
        <translation>Для запуска Systemback необходимы права Root!</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2838"/>
        <location filename="../systemback/systemback.cpp" line="2852"/>
        <location filename="../systemback/systemback.cpp" line="2858"/>
        <location filename="../systemback/systemback.cpp" line="2864"/>
        <location filename="../systemback/systemback.cpp" line="2888"/>
        <source>The system copy is aborted!</source>
        <translation>Копирование системы отменено!</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2838"/>
        <source>The specified partition(s) does not have enough free space to copy the system. The copied system will not function properly.</source>
        <translation>Указанный раздел(ы) не имеет достаточно свободного места для копирования системы. Скопированая система не будет функционировать должным образом.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2840"/>
        <source>The system copy is completed, but an error occurred while installing the GRUB!</source>
        <translation>Копирование системы завершено, но произошла ошибка при установке GRUB!</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2840"/>
        <location filename="../systemback/systemback.cpp" line="2854"/>
        <source>You need to manually install a bootloader.</source>
        <translation>Вы должны вручную установить загрузчик.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2842"/>
        <location filename="../systemback/systemback.cpp" line="2902"/>
        <source>The system restoration is aborted!</source>
        <translation>Восстановление системы отменено!</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2842"/>
        <source>An error occurred while reinstalling the GRUB.</source>
        <translation>Ошибка при переустановке GRUB.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2844"/>
        <source>The full system repair is completed, but an error occurred while reinstalling the GRUB!</source>
        <translation>Полный ремонт системы завершён, но произошла ошибка при переустановке GRUB!</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2846"/>
        <location filename="../systemback/systemback.cpp" line="2848"/>
        <location filename="../systemback/systemback.cpp" line="2850"/>
        <location filename="../systemback/systemback.cpp" line="2878"/>
        <location filename="../systemback/systemback.cpp" line="2880"/>
        <source>The Live system creation is aborted!</source>
        <translation>Создание системы Live отменено!</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2846"/>
        <source>An error occurred while creating the file system image.</source>
        <translation>Ошибка при создании образа файловой системы.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2848"/>
        <source>An error occurred while creating the container file.</source>
        <translation>Ошибка при создании файла-контейнера.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2852"/>
        <location filename="../systemback/systemback.cpp" line="2884"/>
        <location filename="../systemback/systemback.cpp" line="2898"/>
        <source>The specified partition could not be mounted.</source>
        <translation>Указанный раздел не может быть смонтирован.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2854"/>
        <source>The system install is completed, but an error occurred while installing the GRUB!</source>
        <translation>Установка системы завершена, но произошла ошибка при установке GRUB!</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2856"/>
        <location filename="../systemback/systemback.cpp" line="2866"/>
        <location filename="../systemback/systemback.cpp" line="2884"/>
        <location filename="../systemback/systemback.cpp" line="2886"/>
        <location filename="../systemback/systemback.cpp" line="2890"/>
        <source>The system installation is aborted!</source>
        <translation>Установка системы отменена!</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2856"/>
        <source>The specified partition(s) does not have enough free space to install the system. The installed system will not function properly.</source>
        <translation>Указанный раздел(ы) не имеет достаточно свободного места для установки системы. Установленная система не будет функционировать должным образом.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2858"/>
        <location filename="../systemback/systemback.cpp" line="2886"/>
        <location filename="../systemback/systemback.cpp" line="2900"/>
        <source>The specified partition could not be formatted (in use or unavailable).</source>
        <translation>Указанный раздел не может быть отформатирован (используется или недоступен).</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2860"/>
        <source>An error occurred while reinstalling the GRUB!</source>
        <translation>Ошибка при переустановке GRUB!</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2862"/>
        <location filename="../systemback/systemback.cpp" line="2864"/>
        <location filename="../systemback/systemback.cpp" line="2866"/>
        <location filename="../systemback/systemback.cpp" line="2880"/>
        <location filename="../systemback/systemback.cpp" line="2894"/>
        <location filename="../systemback/systemback.cpp" line="2896"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="137"/>
        <source>There has been critical changes in the file system during this operation.</source>
        <translation>Во время этой операции произошли критические изменения в файловой системе.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2868"/>
        <location filename="../systemback/systemback.cpp" line="2870"/>
        <location filename="../systemback/systemback.cpp" line="2896"/>
        <location filename="../systemback/systemback.cpp" line="2898"/>
        <location filename="../systemback/systemback.cpp" line="2900"/>
        <source>The Live write is aborted!</source>
        <translation>Запись Live отменена!</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2868"/>
        <source>The selected device does not have enough space to write the Live system.</source>
        <translation>На выбранном устройстве недостаточно места для записи системы Live.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2870"/>
        <source>An error occurred while unpacking the Live system files.</source>
        <translation>Произошла ошибка при распаковке файлов системы Live.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2872"/>
        <location filename="../systemback/systemback.cpp" line="2874"/>
        <location filename="../systemback/systemback.cpp" line="2876"/>
        <location filename="../systemback/systemback.cpp" line="2894"/>
        <source>The Live conversion is aborted!</source>
        <translation>Преобразование Live отменено!</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2872"/>
        <source>An error occurred while renaming the essential Live files.</source>
        <translation>Ошибка при переименовании основных файлов Live.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2874"/>
        <source>An error occurred while creating the .iso image.</source>
        <translation>Ошибка при создании образа ISO.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2876"/>
        <source>An error occurred while reading the .sblive image.</source>
        <translation>Произошла ошибка при чтении образа .sblive.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2878"/>
        <source>An error occurred while creating the new initramfs image.</source>
        <translation>Ошибка при создании нового образа initramfs.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2882"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="141"/>
        <source>The restore point deletion is aborted!</source>
        <translation>Удаление точки восстановления отменено!</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2882"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="141"/>
        <source>An error occurred while during the process.</source>
        <translation>Ошибка во время процесса.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2888"/>
        <location filename="../systemback/systemback.cpp" line="2890"/>
        <location filename="../systemback/systemback.cpp" line="2892"/>
        <source>The Live image could not be mounted.</source>
        <translation>Образ Live не может быть смонтирован.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2892"/>
        <location filename="../systemback/systemback.cpp" line="2904"/>
        <source>The system repair is aborted!</source>
        <translation>Ремонт системы отменен!</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="2902"/>
        <location filename="../systemback/systemback.cpp" line="2904"/>
        <source>There is not enough free space.</source>
        <translation>Недостаточно свободного места.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="4242"/>
        <location filename="../systemback/systemback.cpp" line="4248"/>
        <location filename="../systemback/systemback.cpp" line="4340"/>
        <location filename="../systemback/systemback.cpp" line="5709"/>
        <location filename="../systemback/systemback.cpp" line="5897"/>
        <source>Multiple mount points</source>
        <translation>Несколько точек монтирования</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="6771"/>
        <source>Enabled</source>
        <translation>Включено</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="6957"/>
        <source>Systemback worker thread is interrupted by the user.</source>
        <translation>Systemback &quot;работа&quot; перервана пользователем.</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="7414"/>
        <source>Boot Live without xorg.conf file</source>
        <translation>Загрузить Live без файла xorg.conf</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="7417"/>
        <location filename="../systemback/systemback.cpp" line="7419"/>
        <location filename="../systemback/systemback.cpp" line="7421"/>
        <source>Boot Live system</source>
        <translation>Загрузить систему Live</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="7417"/>
        <location filename="../systemback/systemback.cpp" line="7419"/>
        <location filename="../systemback/systemback.cpp" line="7421"/>
        <source>Boot system installer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="7417"/>
        <location filename="../systemback/systemback.cpp" line="7419"/>
        <location filename="../systemback/systemback.cpp" line="7421"/>
        <source>Boot Live in safe graphics mode</source>
        <translation>Загрузить Live в безопасном графическом режиме</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="7417"/>
        <location filename="../systemback/systemback.cpp" line="7419"/>
        <location filename="../systemback/systemback.cpp" line="7421"/>
        <source>Boot Live in debug mode</source>
        <translation>Загрузить Live в режиме отладки</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="7418"/>
        <source>Press &apos;E&apos; key to edit</source>
        <translation>Нажмите клавишу &apos;E&apos; для редактирования</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.cpp" line="7421"/>
        <source>Press TAB key to edit</source>
        <translation>Нажмите клавишу TAB для редактирования</translation>
    </message>
    <message>
        <location filename="../systemback/systemback.hpp" line="320"/>
        <source>An error occurred while changing the access permissions of the following file:</source>
        <translation>Произошла ошибка при изменении прав доступа следующего файла:</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="36"/>
        <source>Usage: systemback-cli [option]

 Options:

  -n, --newbackup          create a new restore point

  -s, --storagedir &lt;path&gt;  get or set the restore points storage directory path

  -u, --upgrade            upgrade the current system
                           remove the unnecessary files and packages

  -v, --version            output the Systemback version number

  -h, --help               show this help</source>
        <translation>Использование: systemback-cli [опція]

 Опції:

  -n, --newbackup          создать новую точку восстановления

  -s, --storagedir &lt;path&gt;  путь к каталогу хранения точек восстановления

  -u, --upgrade            обновить существующую систему
                           удалить ненужные файлы и пакеты

  -v, --version            версия Systemback

  -h, --help               показать эту справку</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="82"/>
        <source>basic restore UI</source>
        <translation>основной UI восстановления</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="115"/>
        <source>The Systemback command line interface cannot be used on a Live system!</source>
        <translation>Интерфейс командной строки Systemback не может быть использован на Live системе!</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="125"/>
        <source>This stupid terminal does not support color!</source>
        <translation>Этот тупой терминал не поддерживает цвет!</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="127"/>
        <source>This terminal is too small!</source>
        <translation>Этот терминал слишком мал!</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="129"/>
        <source>The specified storage directory path has not been set!</source>
        <translation>Указанный путь каталога хранения не установлен!</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="131"/>
        <source>The restoration is aborted!</source>
        <translation>Восстановление отменено!</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="133"/>
        <source>The restoration is completed, but an error occurred while reinstalling the GRUB!</source>
        <translation>Восстановление завершено, но возникла ошибка при переустановке GRUB!</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="139"/>
        <source>The restore points storage directory is not available or not writable!</source>
        <translation>Каталог хранения точек восстановления недоступен или недоступен для записи!</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="152"/>
        <source>Available restore point(s):</source>
        <translation>Доступные точки восстановления:</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="179"/>
        <source>Quit</source>
        <translation>Выйти</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="242"/>
        <source>Selected restore point:</source>
        <translation>Выбранная точка восстановления:</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="314"/>
        <source>The specified storage directory path is set.</source>
        <translation>Указанный путь каталога хранения установлен.</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="370"/>
        <source>Restore with the following restore point:</source>
        <translation>Восстановить из указанной точки восстановления:</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="370"/>
        <source>Restore with the following restore method:</source>
        <translation>Восстановить указанным способом восстановления:</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="379"/>
        <source>Users configuration files restore</source>
        <translation>Восстановить конфигурационные файлы пользователей</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="381"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="416"/>
        <source>Complete configuration files restore</source>
        <translation>Восстановить конфигурационные файлы полностью</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="418"/>
        <source>Configuration files restore</source>
        <translation>Восстановить конфигурационные файлы</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="428"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="451"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="479"/>
        <source>You want to keep the current fstab file?</source>
        <translation>Вы хотите сохранить текущий файл fstab?</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="428"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="451"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="456"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="479"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="484"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="507"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="513"/>
        <location filename="../systemback-cli/systemback-cli.hpp" line="69"/>
        <source>(Y/N)</source>
        <translation>(Y/N)</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="456"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="479"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="484"/>
        <location filename="../systemback-cli/systemback-cli.cpp" line="507"/>
        <source>Reinstall the GRUB 2 bootloader?</source>
        <translation>Переустановить загрузчик GRUB 2?</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="513"/>
        <source>Start the restore?</source>
        <translation>Начать восстановление?</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="546"/>
        <source>The users configuration files full restoration are completed.</source>
        <translation>Полное восстановление конфигурационных файлов пользователей завершено.</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="548"/>
        <source>The users configuration files restoration are completed.</source>
        <translation>Восстановление конфигурационных файлов пользователей завершено.</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="553"/>
        <source>Press &apos;ENTER&apos; key to reboot the computer, or &apos;Q&apos; to quit.</source>
        <translation>Нажать клавишу &apos;ENTER&apos;, для перезагрузки компютера или &apos;Q&apos; выхода.</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="553"/>
        <source>Press &apos;ENTER&apos; key to quit.</source>
        <translation>Нажать клавишу &apos;ENTER&apos; для выхода.</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="580"/>
        <source>Deleting old restore point(s)</source>
        <translation>Удаление старых точек восстановления</translation>
    </message>
    <message>
        <location filename="../systemback-cli/systemback-cli.cpp" line="588"/>
        <source>Restoring the users configuration files</source>
        <translation>Восстановление конфигурационных файлов пользователей</translation>
    </message>
</context>
</TS>
