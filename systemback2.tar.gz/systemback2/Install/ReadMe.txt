Install SystemBack:
===================

open a terminal here and type:

sudo dpkg -i *.deb
sudo apt --fix-broken install
